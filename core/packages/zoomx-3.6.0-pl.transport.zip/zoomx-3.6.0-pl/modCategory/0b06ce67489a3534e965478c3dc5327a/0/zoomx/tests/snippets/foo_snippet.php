<?php

return $foo;