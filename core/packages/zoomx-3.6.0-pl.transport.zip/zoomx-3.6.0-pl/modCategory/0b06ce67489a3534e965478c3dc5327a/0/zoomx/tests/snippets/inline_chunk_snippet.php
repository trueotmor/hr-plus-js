<?php

return zoomx()->getChunk($tpl, $scriptProperties);