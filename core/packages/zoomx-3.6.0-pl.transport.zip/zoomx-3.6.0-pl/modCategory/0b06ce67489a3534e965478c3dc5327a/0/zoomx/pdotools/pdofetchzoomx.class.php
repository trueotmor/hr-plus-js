<?php

class pdoFetchZoomx extends pdoFetch
{
    use pdoToolsAdapter;
}