<?php

class pdoToolsZoomx extends pdoTools
{
    use pdoToolsAdapter;
}