--------------------
ZoomX
--------------------
Author: sergant210
--------------------

An Extra for MODx Revolution that implements the logic of PHP template engines.