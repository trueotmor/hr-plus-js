<?php

$_lang['zoomx'] = 'ZoomX';
$_lang['zoomx_parser_implement_error'] = 'Парсер должен имплементировать интерфейс <b>ParserInterface</b>.';
$_lang['zoomx_template_not_found'] = 'Шаблон "[[+name]]" не найден.';
$_lang['zoomx_snippet_file_not_found'] = 'Файл сниппета "[[+name]]" не найден.';
$_lang['zoomx_snippet_not_found'] = 'Сниппет "[[+name]]" не найден.';
$_lang['zoomx_chunk_not_found'] = 'Чанк "[[+name]]" не найден.';
$_lang['zoomx_wrong_redirect_status'] = 'Указан некорректный HTTP код переадресации "[[+status]]".';
$_lang['zoomx_redirect_to_empty_url'] = 'Переадресация на пустой URL невозможна.';

$_lang['zoomx_just_now'] = 'Только что';
$_lang['zoomx_date_today'] = 'Сегодня в';
$_lang['zoomx_date_yesterday'] = 'Вчера в';
$_lang['zoomx_date_tomorrow'] = 'Завтра в';
$_lang['zoomx_date_minutes_back'] = '["[[+minutes]] минута назад","[[+minutes]] минуты назад","[[+minutes]] минут назад"]';
$_lang['zoomx_date_minutes_back_less'] = 'меньше минуты назад';
$_lang['zoomx_date_hours_back'] = '["[[+hours]] час назад","[[+hours]] часа назад","[[+hours]] часов назад"]';
$_lang['zoomx_date_hours_back_less'] = 'меньше часа назад';
$_lang['zoomx_date_days_back'] = '["[[+days]] день назад","[[+days]] дня назад","[[+days]] дней назад"]';
$_lang['zoomx_date_months'] = '["января","февраля","марта","апреля","мая","июня","июля","августа","сентября","октября","ноября","декабря"]';