## str_concat()
Concatenate passed string arguments.

```str_concat()```

```php
$dolar = 'dolar';
str_concat('Lorem', ' ipsum ', $dolar);  // Lorem ipsum dolar
```