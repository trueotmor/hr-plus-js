## pls_delete()
Removes the specified placeholders.

```pls_delete($keys)```

- $keys (string|array) - a placeholder or an array of them.

```php
pls_delete('my.Placeholder');
```