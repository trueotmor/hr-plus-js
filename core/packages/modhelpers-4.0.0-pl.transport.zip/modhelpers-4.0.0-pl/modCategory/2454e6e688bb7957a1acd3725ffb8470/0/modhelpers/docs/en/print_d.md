## print_d()
Prints the value and dies. Converts the given value to the string format and prints  or returns it. 

```print_d($value, $template = '', $tag = 'output')```
- $value(mixed) - the input value.
- $template(string) - HTML template to wrap the output.
- $tag(string) - a tag to be replaced.  
