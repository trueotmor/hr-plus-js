<?php

namespace modHelpers;


class QueueRegister
{
    public function deleteQueue($name)
    {

    }

    public function deleteTopic($name)
    {

    }
}