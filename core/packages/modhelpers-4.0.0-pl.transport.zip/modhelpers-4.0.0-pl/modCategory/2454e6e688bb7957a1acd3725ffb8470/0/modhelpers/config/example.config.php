<?php

return [
    /*'modhelpers_snippets_path' => MODX_CORE_PATH . 'elements/snippets/',
    'modhelpers_chunks_path' => MODX_CORE_PATH . 'elements/chunks/',
    'modhelpers_templates_path' => MODX_CORE_PATH . 'elements/templates/',*/
    /* Below you can add any system settings that you need */
];