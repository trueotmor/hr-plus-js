<?php
$_lang['modhelpers'] = 'modHelpers';