## first()
Return the first not null parameter.

```first()```

```php
$nullObj = null;
$nullArray = null;
$string = '';
$first($nullObj, $nullArray, $string); // ''
```