<?php

/**
 * Helpers files autoloader for tests
 */
require_once __DIR__ . '/../functions/functions.php';