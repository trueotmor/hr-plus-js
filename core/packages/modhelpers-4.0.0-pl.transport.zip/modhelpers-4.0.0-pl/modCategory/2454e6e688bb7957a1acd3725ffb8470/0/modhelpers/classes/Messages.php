<?php

namespace modHelpers;

/**
 * Message Manager.
 * @package modHelpers
 */
class Messages
{

}