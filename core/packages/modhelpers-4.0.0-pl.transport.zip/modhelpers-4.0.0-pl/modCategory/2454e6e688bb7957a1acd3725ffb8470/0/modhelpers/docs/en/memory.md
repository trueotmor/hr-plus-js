## memory()
Displays formatted memory value allocated to PHP.

```memory($unit = 'KB')```
- $unit - Available value - "byte", "KB" and "MB". 

```php
echo memory(); 
```
Can be used with template engines.